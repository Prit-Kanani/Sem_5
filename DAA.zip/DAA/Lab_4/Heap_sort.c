#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 10000  

int readfile(const char *filename, int arr[], int n) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("Cannot open the file %s\n", filename);
        return 0;
    }

    for (int i = 0; i < n && fscanf(f, "%d", &arr[i]) == 1; i++);
    fclose(f);
    return 1;
}

void heapify(int arr[], int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest])
        largest = left;

    if (right < n && arr[right] > arr[largest])
        largest = right;

    if (largest != i) {
        int temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;

        heapify(arr, n, largest);
    }
}

void heapSort(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);

    for (int i = n - 1; i > 0; i--) {
        int temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
        heapify(arr, i, 0);
    }
}

void main() {
    int arr[MAX];
    int n = 100;

    printf("for 100 element\n");

    if (readfile("./../Array/Write_Best_case_100.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("best_case_100 took %.3f ms\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read best_case_100 file.\n");
    }

    if (readfile("./../Array/Write_Average_case_100.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("average_case_100 took %.3f ms\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read average_case_100 file.\n");
    }

    if (readfile("./../Array/Write_Worst_case_100.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("worst_case_100 took %.3f ms\n\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read worst_case_100 file.\n");
    }

    ///////////////////////////////////////////////////////////////
    n = 1000;
    printf("for 1000 element\n");

    if (readfile("./../Array/Write_Best_case_1000.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("best_case_1000 took %.3f ms\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read best_case_1000 file.\n");
    }

    if (readfile("./../Array/Write_Average_case_1000.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("average_case_1000 took %.3f ms\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read average_case_1000 file.\n");
    }

    if (readfile("./../Array/Write_Worst_case_1000.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("worst_case_1000 took %.3f ms\n\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read worst_case_1000 file.\n");
    }

    ///////////////////////////////////////////////////////////////
    n = 10000;
    printf("for 10000 element\n");

    if (readfile("./../Array/Write_Best_case_10000.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("best_case_10000 took %.3f ms\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read best_case_10000 file.\n");
    }

    if (readfile("./../Array/Write_Average_case_10000.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("average_case_10000 took %.3f ms\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read average_case_10000 file.\n");
    }

    if (readfile("./../Array/Write_Worst_case_10000.txt", arr, n)) {
        clock_t start = clock();
        heapSort(arr, n);
        clock_t end = clock();
        printf("worst_case_10000 took %.3f ms\n", ((double)(end - start)) / CLOCKS_PER_SEC * 1000);
    } else {
        printf("Failed to read worst_case_10000 file.\n");
    }
}
