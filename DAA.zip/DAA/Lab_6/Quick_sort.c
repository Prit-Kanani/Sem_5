#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 10000

int readfile(const char *filename, int arr[], int n) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("Cannot open the file %s\n", filename);
        return 0;
    }

    for (int i = 0; i < n; i++) {
        fscanf(f, "%d", &arr[i]);
    }
    fclose(f);
    return 1;
}

int partition(int arr[], int low, int high) {
    int pivot = arr[high]; // last element as pivot
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            int temp = arr[i]; 
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    int temp = arr[i + 1]; arr[i + 1] = arr[high]; arr[high] = temp;
    return i + 1;
}

void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main() {
    int arr[MAX];
    int n;
    clock_t start, end;
    double time_taken;

    // ------------------- 100 elements -------------------
    n = 100;
    printf("--------------------------------------\nFor 100 elements\n");

    if (readfile("../Array/Write_Best_case_100.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Best case (100): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Average_case_100.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Average case (100): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Worst_case_100.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Worst case (100): %.3f ms\n", time_taken);
    }

    // ------------------- 1000 elements -------------------
    n = 1000;
    printf("--------------------------------------\nFor 1000 elements\n");

    if (readfile("../Array/Write_Best_case_1000.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Best case (1000): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Average_case_1000.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Average case (1000): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Worst_case_1000.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Worst case (1000): %.3f ms\n", time_taken);
    }

    // ------------------- 10000 elements -------------------
    n = 10000;
    printf("--------------------------------------\nFor 10000 elements\n");

    if (readfile("../Array/Write_Best_case_10000.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Best case (10000): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Average_case_10000.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Average case (10000): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Worst_case_10000.txt", arr, n)) {
        start = clock();
        quickSort(arr, 0, n - 1);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Worst case (10000): %.3f ms\n", time_taken);
    }

    return 0;
}
