#include <stdio.h>
#include <time.h>
#define MAX 10000 

int readfile(const char *filename, int arr[], int n) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("Cannot open the file %s\n", filename);
        return 0;
    }

    for (int i = 0; i < n; i++) {
        fscanf(f, "%d", &arr[i]);
    }
    fclose(f);
    return 1;
}

void Linear_search(int arr[], int value, int n) {
    for (int i = 0; i < n; i++) {
        if (arr[i] == value) {
            printf("The value %d has been found at index %d!\n", value, i);
            return;
        }
    }
    printf("The value %d is not in the array!\n", value);
}

int main() {
    int arr[MAX];
    int n;
    clock_t start, end;
    double time_taken;

    // For 100 elements
    n = 100;
    printf("--------------------------------------\nFor 100 elements\n");

    if (readfile("../Array/Write_Best_case_100.txt", arr, n)) {
        start = clock();
        Linear_search(arr, 90, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Time taken: %.3f ms\n", time_taken);
    } else {
        printf("Failed to read the file.\n");
    }

    // For 1000 elements
    n = 1000;
    printf("--------------------------------------\nFor 1000 elements\n");

    if (readfile("../Array/Write_Best_case_1000.txt", arr, n)) {
        start = clock();
        Linear_search(arr, 900, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Time taken: %.3f ms\n", time_taken);
    } else {
        printf("Failed to read the file.\n");
    }

    // For 10000 elements
    n = 10000;
    printf("--------------------------------------\nFor 10000 elements\n");

    if (readfile("../Array/Write_Best_case_10000.txt", arr, n)) {
        start = clock();
        Linear_search(arr, 9000, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Time taken: %.3f ms\n", time_taken);
    } else {
        printf("Failed to read the file.\n");
    }

    return 0;
}
