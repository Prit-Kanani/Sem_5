#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAX 10000

int readfile(const char *filename, int arr[], int n) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("Cannot open the file %s\n", filename);
        return 0;
    }

    for (int i = 0; i < n; i++) {
        fscanf(f, "%d", &arr[i]);
    }
    fclose(f);
    return 1;
}

int binary(int arr[], int l, int h, int value) {
    if (l > h) {
        return -1;  // Not found
    }

    int mid = l + (h - l) / 2;

    if (arr[mid] == value)
        return mid;
    else if (arr[mid] > value)
        return binary(arr, l, mid - 1, value);
    else
        return binary(arr, mid + 1, h, value);
}

int main() {
    int arr[MAX];
    int n = 100;
    int value = 80;

    printf("--------------------------------------\nfor 100 element\n");

    if (readfile("../Array/Write_Best_case_100.txt", arr, n)) {
        clock_t start = clock();
        int result = binary(arr, 0, n - 1, value);
        clock_t end = clock();

        if (result != -1)
            printf("Value %d found at index %d\n", value, result);
        else
            printf("Value %d not found!\n", value);

        double time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Time taken: %.3f ms\n", time_taken);
    } else {
        printf("Failed to read the file.\n");
    }

    return 0;
}
