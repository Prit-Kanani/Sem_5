#include <stdio.h>
#include <time.h>
#define MAX 10000 

int readfile(const char *filename, int arr[], int n) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("Cannot open the file %s\n", filename);
        return 0;
    }

    for (int i = 0; i < n; i++) {
        fscanf(f, "%d", &arr[i]);
    }
    fclose(f);
    return 1;
}

int binary(int arr[], int n, int t) {
    int l = 0, h = n - 1;
    while (l <= h) {
        int m = (l + h) / 2;
        if (arr[m] == t)
            return m;
        else if (arr[m] < t)
            l = m + 1;
        else
            h = m - 1;
    }
    return -1;
}

int main() {
    int arr[MAX];
    int n;
    int target, result;
    clock_t start, end;
    double time_taken;

    // ---------- 100 elements ----------
    n = 100;
    target = 90;
    printf("--------------------------------------\nFor 100 elements\n");

    if (readfile("../Array/Write_Best_case_100.txt", arr, n)) {
        start = clock();
        result = binary(arr, n, target);
        end = clock();

        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        if (result != -1)
            printf("Value %d found at index %d\n", target, result);
        else
            printf("Value %d not found\n", target);
        printf("Time taken: %.3f ms\n", time_taken);
    } else {
        printf("Failed to read the file.\n");
    }

    // ---------- 1000 elements ----------
    n = 1000;
    target = 900;
    printf("--------------------------------------\nFor 1000 elements\n");

    if (readfile("../Array/Write_Best_case_1000.txt", arr, n)) {
        start = clock();
        result = binary(arr, n, target);
        end = clock();

        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        if (result != -1)
            printf("Value %d found at index %d\n", target, result);
        else
            printf("Value %d not found\n", target);
        printf("Time taken: %.3f ms\n", time_taken);
    } else {
        printf("Failed to read the file.\n");
    }

    // ---------- 10000 elements ----------
    n = 10000;
    target = 9000;
    printf("--------------------------------------\nFor 10000 elements\n");

    if (readfile("../Array/Write_Best_case_10000.txt", arr, n)) {
        start = clock();
        result = binary(arr, n, target);
        end = clock();

        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        if (result != -1)
            printf("Value %d found at index %d\n", target, result);
        else
            printf("Value %d not found\n", target);
        printf("Time taken: %.3f ms\n", time_taken);
    } else {
        printf("Failed to read the file.\n");
    }

    return 0;
}
