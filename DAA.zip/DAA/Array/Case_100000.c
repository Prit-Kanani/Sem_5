#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 100000

void Write_Worst_case()
{
    FILE *f = fopen("Write_Worst_case_100000.txt", "w");
    for (int i = N - 1; i >= 0; i--)
    {
        fprintf(f, "%d ", i + 1);
    }
    fclose(f);
}

void Write_Best_case()
{
    FILE *f = fopen("Write_Best_case_100000.txt", "w");
    for (int i = 0; i < N; i++)
    {
        fprintf(f, "%d ", i + 1);
    }
    fclose(f);
}

void Write_Average_case()
{
    FILE *f = fopen("Write_Average_case_100000.txt", "w");
    int i = 1;
    int j = 2;
    while (i <= N && j <= N)
    {
        fprintf(f, "%d ", j);
        fprintf(f, "%d ", i);
        j += 2;
        i += 2;
    }
    fclose(f);
}

void main()
{
    Write_Worst_case();
    Write_Average_case();
    Write_Best_case();
}