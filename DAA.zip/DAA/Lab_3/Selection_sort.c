#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 10000

int readfile(const char *filename, int arr[], int n) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("Cannot open the file %s\n", filename);
        return 0;
    }

    for (int i = 0; i < n; i++) {
        fscanf(f, "%d", &arr[i]);
    }
    fclose(f);
    return 1;
}

void selectionSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx]) {
                minIdx = j;
            }
        }
        if (minIdx != i) {
            int temp = arr[i];
            arr[i] = arr[minIdx];
            arr[minIdx] = temp;
        }
    }
}

int main() {
    int arr[MAX];
    int n;
    clock_t start, end;
    double time_taken;

    // ---------------------- 100 elements ----------------------
    n = 100;
    printf("--------------------------------------\nFor 100 elements\n");

    if (readfile("../Array/Write_Best_case_100.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Best case (100): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Average_case_100.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Average case (100): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Worst_case_100.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Worst case (100): %.3f ms\n", time_taken);
    }

    // ---------------------- 1000 elements ----------------------
    n = 1000;
    printf("--------------------------------------\nFor 1000 elements\n");

    if (readfile("../Array/Write_Best_case_1000.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Best case (1000): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Average_case_1000.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Average case (1000): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Worst_case_1000.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Worst case (1000): %.3f ms\n", time_taken);
    }

    // ---------------------- 10000 elements ----------------------
    n = 10000;
    printf("--------------------------------------\nFor 10000 elements\n");

    if (readfile("../Array/Write_Best_case_10000.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Best case (10000): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Average_case_10000.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Average case (10000): %.3f ms\n", time_taken);
    }

    if (readfile("../Array/Write_Worst_case_10000.txt", arr, n)) {
        start = clock();
        selectionSort(arr, n);
        end = clock();
        time_taken = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;
        printf("Worst case (10000): %.3f ms\n", time_taken);
    }

    return 0;
}
