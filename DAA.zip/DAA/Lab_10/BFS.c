#include<stdio.h>

#define V 8

int graph[V][V];
int visited[V];

void BFS(int start){
    int queue[V];
    int front = 0, rear = 0;

    visited[start] = 1;
    queue[rear++] = start;
    
    while(front < rear){
        int vertex = queue[front++];
        printf("Visited %d\n", vertex );
        for (int i = 0; i < V; i++) {
            if (graph[vertex][i] == 1 && !visited[i]) {
                visited[i] = 1;
                queue[rear++] = i;
            }
        }
    }
}

void main(){
    int edges[][2] = {
        {0, 1},
        {0, 2},
        {0, 3},
        {0, 4},
        {1, 5},
        {2, 5},
        {3, 6},
        {4, 6},
        {5, 7},
        {6, 7}
    };
    int edgeCount = sizeof(edges) / sizeof(edges[0]);

    for (int i = 0; i < edgeCount; i++) {
        int x = edges[i][0];
        int y = edges[i][1];
        graph[x][y] = 1;
        graph[y][x] = 1;
    }
    BFS(0);
}