#include<stdio.h>
int stack[100];
int top = -1;
void push(){
    if(top + 1 >= 100){
        printf("Stack Overflow!");
    }
    else{
        printf("Enter a no. : ");
        scanf("%d",&stack[++top]);
    }
}
void peep(){
    if(top < 0){
        printf("Stack underflow!");
    }
    else{
        printf("the top element is : %d",stack[top]);
    }
}
void pop(){
    if(top < 0){
        printf("Satck underflow!");
    }
    else{
        printf("\nthe poped element is : %d",stack[top--]);
    }
}
void main(){
    int temp = -1;
    while(1){
        printf("\n1. for push \n2. for peep \n3. for pop : ");
        scanf("%d",&temp);
        if(temp==1){
            push();
        }
        else if(temp == 2){
            peep();
        }
        else if (temp == 3){
            pop();
        }
        else{
            break;
        }
    }

}