#include<stdio.h>
int queue[100];
int f = -1;
int r = -1;
void enqueue(){
    if(f>99){
        printf("\nThe queue is overflow!");
    }
    else{
        printf("\nEnter the element : ");
        scanf("%d",&queue[++f]);
        if(r==-1){
            r++;
        }
    }
}
void dequeue(){
    if(r == -1){
        printf("\nThe queue is underflow!");
        return;
    }
    printf("\nThe poped element is : %d",queue[r]);
    if(r==f){
        r = -1;
        f = r;
    }
    else{
        r++;
    }
}
void display(){
    if (r == -1){
        printf("\nQueue underfloqw!");
    }
    else{
        printf("\nthe rear element is %d",queue[r]);
    }
}
void main(){
    int temp = -1;
    while(1){
        printf("\n1. for enqueue \n2. for display \n3. for dequeue : ");
        scanf("%d",&temp);
        if(temp==1){
            enqueue();
        }
        else if(temp == 2){
            display();
        }
        else if (temp == 3){
            dequeue();
        }
        else{
            break;
        }
    }
}
